library ieee;
use ieee.std_logic_1164.all;

ENTITY decoder IS
	PORT(
		A: OUT std_logic_vector (3 downto 0);
		S: IN std_logic_vector (1 downto 0)
	);
END decoder;

ARCHITECTURE Behaviour OF decoder IS
BEGIN
	process(S)
	begin
	  case S is
			when "00" => A <= "1110";
			when "01" => A <= "1101";
			when "10" => A <= "1011";
			when "11" => A <= "0111";
			--when "00" => A <= "0111";
			--when "01" => A <= "1011";
			--when "10" => A <= "1101";
			--when "11" => A <= "1110";
			when others => A <= "1111";
	  end case;
	end process;
END Behaviour;