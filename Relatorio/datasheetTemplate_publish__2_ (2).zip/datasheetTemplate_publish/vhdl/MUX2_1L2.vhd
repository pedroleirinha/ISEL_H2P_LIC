library ieee;
use ieee.std_logic_1164.all;

ENTITY MUX2_1L2 IS
	PORT(
		A,B: IN std_logic_vector (1 downto 0);
		S: IN std_logic;
		Y: OUT std_logic_vector (1 downto 0)
	);
END MUX2_1L2;

ARCHITECTURE Behaviour OF MUX2_1L2 IS
BEGIN
	Y(0) <= (A(0) AND NOT S) OR (B(0) AND S);
	Y(1) <= (A(1) AND NOT S) OR (B(1) AND S);
	
END Behaviour;